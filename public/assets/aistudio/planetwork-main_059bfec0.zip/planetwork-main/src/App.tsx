import { useState, useRef, useEffect, useCallback } from 'react';
import { Check, Plus } from 'lucide-react';
import TaskList from '@/components/TaskList';
import DateTimeCards from '@/components/DateTimeCards';
import Timeline from '@/components/Timeline';
import ProjectProgress from '@/components/ProjectProgress';
import SideRail from '@/components/SideRail';
import IdeaButton from '@/components/IdeaButton';
import CollapsibleSection from '@/components/CollapsibleSection';
import OtherTasksSection from '@/components/OtherTasksSection';
import NavDot from '@/components/NavDot';
import WeatherStrip from '@/components/WeatherStrip';
import SchedulePage from '@/pages/SchedulePage';
import ProjectsPage from '@/pages/ProjectsPage';
import EssentialsPage from '@/pages/EssentialsPage';
import FocusPage from '@/pages/FocusPage';
import OtherTasksPage from '@/pages/OtherTasksPage';
import NewIdeaPage from '@/pages/NewIdeaPage';
import LearningPage from '@/pages/LearningPage';
import ThemesPage from '@/pages/ThemesPage';
import TaskDetailPage from '@/pages/TaskDetailPage';
import NewTaskPage from '@/pages/NewTaskPage';
import { events, projects, type Task } from '@/data';
import { fetchTasksByCategory, toggleTaskDone, type TaskRow } from '@/lib/tasks';

function SectionHeader({ kicker, title }: { kicker: string; title: string }) {
  return (
    <div className="mb-4">
      <h2 className="text-sm tracking-[0.2em] uppercase text-white/50">{kicker}</h2>
      <p className="text-lg font-light text-white/90 mt-0.5">{title}</p>
    </div>
  );
}

function rowToTask(row: TaskRow): Task {
  return {
    id: row.id,
    label: row.label,
    done: row.done,
    tag: row.tag ?? undefined,
    start: row.start_time ?? undefined,
    due: row.due_time ?? undefined,
  };
}

export default function App() {
  const [page, setPage] = useState('home');
  const [activeTaskId, setActiveTaskId] = useState<string | null>(null);
  const [ess, setEss] = useState<Task[]>([]);
  const [focus, setFocus] = useState<Task[]>([]);
  const [other, setOther] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const scrollRestoreRef = useRef<number | null>(null);

  const loadAll = useCallback(async () => {
    try {
      const [e, f, o] = await Promise.all([
        fetchTasksByCategory('essential'),
        fetchTasksByCategory('focus'),
        fetchTasksByCategory('other'),
      ]);
      setEss(e.map(rowToTask));
      setFocus(f.map(rowToTask));
      setOther(o.map(rowToTask));
    } catch {
      // keep empty on error
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  const toggleTask = (setter: React.Dispatch<React.SetStateAction<Task[]>>) =>
    async (id: string) => {
      let newDone = false;
      setter((prev) => prev.map((t) => {
        if (t.id === id) { newDone = !t.done; return { ...t, done: newDone }; }
        return t;
      }));
      try {
        await toggleTaskDone(id, newDone);
      } catch {
        setter((prev) => prev.map((t) => (t.id === id ? { ...t, done: !newDone } : t)));
      }
    };

  const handleAdd = () => {
    navigate('new-task');
  };

  const navigate = (p: string) => {
    if (page === 'home' && p !== 'home') {
      scrollRestoreRef.current = window.scrollY;
      setPage(p);
    } else if (p === 'home') {
      setPage('home');
    } else {
      setPage(p);
      window.scrollTo({ top: 0 });
    }
  };

  useEffect(() => {
    if (page === 'home' && scrollRestoreRef.current !== null) {
      requestAnimationFrame(() => {
        window.scrollTo({ top: scrollRestoreRef.current!, behavior: 'auto' });
        scrollRestoreRef.current = null;
      });
    }
  }, [page]);

  const openTask = (id: string) => {
    if (page === 'home') scrollRestoreRef.current = window.scrollY;
    setActiveTaskId(id);
    setPage('task-detail');
    window.scrollTo({ top: 0 });
  };

  const railNavigate = (key: string) => {
    const sectionMap: Record<string, string | null> = {
      home: 'top',
      schedule: 'schedule',
      inbox: 'other-tasks',
      learning: null,
      themes: null,
    };
    const sectionId = sectionMap[key];
    if (sectionId && page === 'home') {
      document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
      navigate(key === 'home' ? 'home' : key);
    }
  };

  const back = () => navigate('home');

  // ---- Full pages ----
  if (page === 'schedule') return <SchedulePage onBack={back} />;
  if (page === 'projects') return <ProjectsPage onBack={back} />;
  if (page === 'routine')
    return <EssentialsPage tasks={ess} onToggle={toggleTask(setEss)} onOpenTask={openTask} onBack={back} />;
  if (page === 'focus-detail')
    return <FocusPage tasks={focus} onToggle={toggleTask(setFocus)} onOpenTask={openTask} onBack={back} />;
  if (page === 'task-list')
    return <OtherTasksPage tasks={other} onToggle={toggleTask(setOther)} onOpenTask={openTask} onBack={back} />;
  if (page === 'new-space') return <NewIdeaPage onBack={back} />;
  if (page === 'learning') return <LearningPage onBack={back} />;
  if (page === 'themes') return <ThemesPage onBack={back} />;
  if (page === 'task-detail' && activeTaskId)
    return <TaskDetailPage taskId={activeTaskId} onBack={back} />;
  if (page === 'new-task')
    return (
      <NewTaskPage
        onBack={back}
        onCreated={() => {
          loadAll();
          back();
        }}
      />
    );

  // ---- Homepage ----
  return (
    <>
      <div className="aurora-bg">
        <div className="aurora-blob blue" />
        <div className="aurora-blob violet" />
        <div className="aurora-blob magenta" />
      </div>

      <div id="top" className="relative z-10 min-h-screen flex justify-center">
        <main className="w-full max-w-2xl px-5 sm:px-7 py-8 sm:py-12">
          <header className="mb-6 flex flex-col items-center gap-2.5">
            <div className="flex items-center gap-3 self-start">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-sky-400 via-violet-500 to-fuchsia-500 shadow-[0_0_18px_rgba(139,92,246,0.45)]" />
              <h1 className="text-xl font-medium tracking-tight text-white">Alien's Planet</h1>
            </div>
            <IdeaButton onClick={() => navigate('new-space')} />
          </header>

          <div className="flex gap-7">
            <div className="flex-1 flex flex-col gap-6 min-w-0">
              {/* 2. Date & Time */}
              <DateTimeCards onNavigate={navigate} />

              {/* 3. Weather strip */}
              <WeatherStrip />

              {/* 4. Schedule */}
              <div id="schedule">
                <Timeline onNavigate={navigate} />
              </div>

              {/* 5. Project Progress */}
              <div id="projects">
                <ProjectProgress projects={projects} onNavigate={navigate} />
              </div>

              {/* 6. Daily Essentials */}
              <CollapsibleSection
                kicker="Daily"
                title="Essentials"
                defaultVisibleCount={3}
                onNavigate={() => navigate('routine')}
              >
                {(visible) => (
                  <TaskList
                    tasks={visible === -1 ? ess : ess.slice(0, visible)}
                    onToggle={toggleTask(setEss)}
                    onOpenTask={openTask}
                  />
                )}
              </CollapsibleSection>

              {/* 7. Today's Focus */}
              <section id="focus" className="glass glass-glow rounded-3xl p-5 sm:p-6">
                <div className="flex items-start justify-between mb-4">
                  <SectionHeader kicker="Priority" title="Today's Focus" />
                  <NavDot label="Open Focus page" onClick={() => navigate('focus-detail')} />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {focus.slice(0, 3).map((t) => (
                    <div
                      key={t.id}
                      onClick={() => openTask(t.id)}
                      className="glass glass-glow glass-hover rounded-2xl p-4 text-left flex flex-col gap-3 cursor-pointer"
                    >
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <span className="text-[11px] tracking-wide text-white/45 uppercase">{t.tag}</span>
                        <div className="flex items-center gap-2">
                          {t.start && (
                            <span className="text-[10px] tabular-nums text-white/45">Start {t.start}</span>
                          )}
                          {t.due && (
                            <span className="flex items-center gap-1 text-[10px] tabular-nums text-fuchsia-300/70">
                              <span className="w-1 h-1 rounded-full bg-fuchsia-400" />
                              {t.due}
                            </span>
                          )}
                        </div>
                      </div>
                      <p
                        className={`text-[14px] leading-snug transition-all duration-200 ${
                          t.done ? 'text-white/40 line-through' : 'text-white/90'
                        }`}
                      >
                        {t.label}
                      </p>
                      <div
                        className="flex items-center gap-2 mt-auto"
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleTask(setFocus)(t.id);
                        }}
                      >
                        <span className={`check ${t.done ? 'checked' : ''}`}>
                          <Check size={14} strokeWidth={3} color="#fff" />
                        </span>
                        <span className="text-[11px] text-white/40">
                          {t.done ? 'Done' : 'Mark done'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              {/* 8. Other Tasks */}
              <OtherTasksSection
                tasks={other}
                onToggle={toggleTask(setOther)}
                onNavigate={() => navigate('task-list')}
                onOpenTask={openTask}
              />

              <button
                onClick={handleAdd}
                className="flex items-center justify-center gap-2 py-3 rounded-2xl border border-dashed border-white/15 text-white/40 hover:text-white/70 hover:border-white/25 transition-colors text-[13px]"
              >
                <Plus size={16} strokeWidth={2} />
                Add task
              </button>

              <footer className="text-center text-[11px] text-white/25 tracking-wide py-4">
                {new Date().getFullYear()}
              </footer>
            </div>

            <SideRail currentPage={page} onNavigate={railNavigate} onAdd={handleAdd} />
          </div>
        </main>
      </div>
    </>
  );
}
