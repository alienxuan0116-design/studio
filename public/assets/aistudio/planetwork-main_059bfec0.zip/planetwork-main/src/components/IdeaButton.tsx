import { Sparkle } from 'lucide-react';

export default function IdeaButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      aria-label="Open New Space"
      title="New Space"
      className="w-7 h-7 rounded-full flex items-center justify-center text-white/40 hover:text-white/70 border border-white/10 bg-white/5 hover:bg-white/10 transition-colors"
    >
      <Sparkle size={14} strokeWidth={1.5} />
    </button>
  );
}
