export default function NavDot({ onClick, label }: { onClick: () => void; label: string }) {
  return (
    <button
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
      aria-label={label}
      title={label}
      className="flex-shrink-0 w-2.5 h-2.5 rounded-full bg-white/70 hover:bg-white transition-colors"
    />
  );
}
