import { Home, Calendar, GraduationCap, Palette, Inbox, Plus } from 'lucide-react';

interface Props {
  currentPage: string;
  onNavigate: (page: string) => void;
  onAdd: () => void;
}

const ITEMS = [
  { key: 'home', icon: Home, label: 'Home' },
  { key: 'schedule', icon: Calendar, label: 'Schedule' },
  { key: 'learning', icon: GraduationCap, label: 'Learning' },
  { key: 'themes', icon: Palette, label: 'Themes' },
  { key: 'inbox', icon: Inbox, label: 'Inbox' },
];

export default function SideRail({ currentPage, onNavigate, onAdd }: Props) {
  return (
    <div className="hidden lg:flex flex-col items-center gap-3 sticky top-6 h-fit">
      <div className="glass glass-glow rounded-2xl p-2 flex flex-col gap-2">
        {ITEMS.map(({ key, icon: Icon, label }) => (
          <button
            key={key}
            onClick={() => onNavigate(key)}
            title={label}
            aria-label={label}
            className={`rail-icon w-12 h-12 rounded-xl flex items-center justify-center text-white/70 ${
              currentPage === key ? 'active text-white' : ''
            }`}
          >
            <Icon size={20} strokeWidth={1.8} />
          </button>
        ))}
      </div>
      <button
        onClick={onAdd}
        aria-label="Add task"
        title="Add task"
        className="add-btn w-12 h-12 rounded-xl flex items-center justify-center text-white"
      >
        <Plus size={22} strokeWidth={2.4} />
      </button>
    </div>
  );
}
