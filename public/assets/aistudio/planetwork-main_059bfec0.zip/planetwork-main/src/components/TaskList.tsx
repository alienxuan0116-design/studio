import { useEffect, useState } from 'react';
import { Check } from 'lucide-react';
import type { Task } from '@/data';

interface Props {
  tasks: Task[];
  onToggle: (id: string) => void;
  onOpenTask?: (id: string) => void;
}

export default function TaskList({ tasks, onToggle, onOpenTask }: Props) {
  const [local, setLocal] = useState(tasks);

  useEffect(() => setLocal(tasks), [tasks]);

  return (
    <div className="flex flex-col gap-1.5">
      {local.map((task) => (
        <div
          key={task.id}
          className="flex items-center gap-2.5 w-full text-left py-2.5 px-2 rounded-xl hover:bg-white/5 transition-colors duration-200"
        >
          <button
            onClick={(e) => {
              e.stopPropagation();
              setLocal((prev) => prev.map((t) => (t.id === task.id ? { ...t, done: !t.done } : t)));
              onToggle(task.id);
            }}
            className={`check ${task.done ? 'checked' : ''} flex-shrink-0`}
            aria-label={task.done ? 'Mark undone' : 'Mark done'}
          >
            <Check size={14} strokeWidth={3} color="#fff" />
          </button>
          <button
            onClick={() => onOpenTask?.(task.id)}
            className="flex-1 min-w-0 flex flex-col gap-0.5 text-left"
          >
            <span
              className={`text-[15px] truncate transition-all duration-200 ${
                task.done ? 'text-white/40 line-through' : 'text-white/90'
              }`}
            >
              {task.label}
            </span>
            {(task.start || task.due) && (
              <div className="flex items-center gap-2.5 text-[11px] tabular-nums text-white/45">
                {task.start && <span>Start {task.start}</span>}
                {task.due && (
                  <span className="flex items-center gap-1 text-fuchsia-300/75">
                    <span className="w-1 h-1 rounded-full bg-fuchsia-400" />
                    Due {task.due}
                  </span>
                )}
              </div>
            )}
          </button>
          {task.tag && (
            <span className="text-[11px] tracking-wide text-white/40 uppercase px-2 py-0.5 rounded-full border border-white/10 flex-shrink-0">
              {task.tag}
            </span>
          )}
        </div>
      ))}
    </div>
  );
}
