import { supabase } from '@/lib/supabase';

export interface TaskRow {
  id: string;
  label: string;
  description: string | null;
  done: boolean;
  category: 'essential' | 'focus' | 'other';
  tag: string | null;
  project_id: string | null;
  start_time: string | null;
  due_time: string | null;
  priority: string | null;
  task_type: 'essential' | 'single' | 'project' | 'learning';
  sort_order: number;
}

export interface SubtaskRow {
  id: string;
  task_id: string;
  label: string;
  done: boolean;
  sort_order: number;
}

export async function fetchTasksByCategory(category: 'essential' | 'focus' | 'other'): Promise<TaskRow[]> {
  const { data, error } = await supabase
    .from('tasks')
    .select('*')
    .eq('category', category)
    .order('sort_order', { ascending: true });
  if (error) throw error;
  return (data as TaskRow[]) ?? [];
}

export async function fetchTask(id: string): Promise<TaskRow | null> {
  const { data, error } = await supabase
    .from('tasks')
    .select('*')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data as TaskRow | null;
}

export async function fetchSubtasks(taskId: string): Promise<SubtaskRow[]> {
  const { data, error } = await supabase
    .from('subtasks')
    .select('*')
    .eq('task_id', taskId)
    .order('sort_order', { ascending: true });
  if (error) throw error;
  return (data as SubtaskRow[]) ?? [];
}

export async function toggleTaskDone(id: string, done: boolean): Promise<void> {
  const { error } = await supabase.from('tasks').update({ done }).eq('id', id);
  if (error) throw error;
}

export async function updateTask(id: string, updates: Partial<TaskRow>): Promise<void> {
  const { error } = await supabase.from('tasks').update(updates).eq('id', id);
  if (error) throw error;
}

export async function createTask(task: Partial<TaskRow>): Promise<TaskRow | null> {
  const { data, error } = await supabase
    .from('tasks')
    .insert(task)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data as TaskRow | null;
}

export async function deleteTask(id: string): Promise<void> {
  const { error } = await supabase.from('tasks').delete().eq('id', id);
  if (error) throw error;
}

export async function addSubtask(taskId: string, label: string): Promise<SubtaskRow | null> {
  const { data, error } = await supabase
    .from('subtasks')
    .insert({ task_id: taskId, label })
    .select()
    .maybeSingle();
  if (error) throw error;
  return data as SubtaskRow | null;
}

export async function toggleSubtask(id: string, done: boolean): Promise<void> {
  const { error } = await supabase.from('subtasks').update({ done }).eq('id', id);
  if (error) throw error;
}

export async function updateSubtask(id: string, label: string): Promise<void> {
  const { error } = await supabase.from('subtasks').update({ label }).eq('id', id);
  if (error) throw error;
}

export async function deleteSubtask(id: string): Promise<void> {
  const { error } = await supabase.from('subtasks').delete().eq('id', id);
  if (error) throw error;
}
