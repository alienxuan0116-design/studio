import { Check } from 'lucide-react';
import PageShell from '../components/PageShell';
import type { Task } from '@/data';

interface Props {
  tasks: Task[];
  onToggle: (id: string) => void;
  onOpenTask: (id: string) => void;
  onBack: () => void;
}

export default function FocusPage({ tasks, onToggle, onOpenTask, onBack }: Props) {
  return (
    <PageShell title="Today's Focus" subtitle="Priority tasks for today" onBack={onBack}>
      <div className="flex flex-col gap-3">
        {tasks.map((t) => (
          <div
            key={t.id}
            className="flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
          >
            <button
              onClick={() => onToggle(t.id)}
              className={`check ${t.done ? 'checked' : ''} flex-shrink-0`}
              aria-label={t.done ? 'Mark undone' : 'Mark done'}
            >
              <Check size={14} strokeWidth={3} color="#fff" />
            </button>
            <button onClick={() => onOpenTask(t.id)} className="flex-1 text-left min-w-0">
              <p className={`text-[14px] ${t.done ? 'text-white/40 line-through' : 'text-white/85'}`}>{t.label}</p>
              <p className="text-[11px] text-white/45">
                {t.start && `Start ${t.start}`}
                {t.due && ` · Due ${t.due}`}
              </p>
            </button>
          </div>
        ))}
      </div>
    </PageShell>
  );
}
