import { useState } from 'react';
import { Lightbulb, Plus } from 'lucide-react';
import PageShell from '../components/PageShell';

interface Props {
  onBack: () => void;
}

export default function NewIdeaPage({ onBack }: Props) {
  const [text, setText] = useState('');

  return (
    <PageShell title="New Idea" subtitle="Capture a thought for later" onBack={onBack}>
      <div className="flex flex-col gap-4">
        <div className="flex items-center gap-2 text-white/40">
          <Lightbulb size={16} strokeWidth={1.6} />
          <span className="text-[13px]">Ideas are stored for this session only.</span>
        </div>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Type your idea..."
          className="w-full min-h-[120px] rounded-2xl bg-white/5 border border-white/10 p-4 text-[14px] text-white/90 placeholder:text-white/30 focus:outline-none focus:border-white/25 transition-colors resize-none"
        />
        <button
          disabled={!text.trim()}
          onClick={() => setText('')}
          className="flex items-center justify-center gap-2 py-3 rounded-2xl bg-gradient-to-r from-sky-500/80 to-violet-500/80 text-white/90 text-[13px] disabled:opacity-30 disabled:cursor-not-allowed hover:from-sky-500 hover:to-violet-500 transition-all"
        >
          <Plus size={16} strokeWidth={2} />
          Save idea
        </button>
      </div>
    </PageShell>
  );
}
