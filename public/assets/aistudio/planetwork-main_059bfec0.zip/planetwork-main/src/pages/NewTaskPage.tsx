import { useState } from 'react';
import { Check, Sparkles, ListTodo, Briefcase, GraduationCap } from 'lucide-react';
import PageShell from '@/components/PageShell';
import { createTask, type TaskRow } from '@/lib/tasks';

interface Props {
  onBack: () => void;
  onCreated: (task: TaskRow) => void;
}

const TASK_TYPES = [
  { value: 'essential', label: 'Daily Essential', icon: Check, category: 'essential' as const, desc: 'Recurring routine task' },
  { value: 'single', label: 'Single Task', icon: ListTodo, category: 'other' as const, desc: 'One-time task' },
  { value: 'project', label: 'Project Task', icon: Briefcase, category: 'focus' as const, desc: 'Short-term project work' },
  { value: 'learning', label: 'Learning Task', icon: GraduationCap, category: 'other' as const, desc: 'Long-term learning goal' },
];

const PRIORITIES = [
  { value: 'low', label: 'Low' },
  { value: 'medium', label: 'Medium' },
  { value: 'high', label: 'High' },
];

export default function NewTaskPage({ onBack, onCreated }: Props) {
  const [step, setStep] = useState<'type' | 'details'>('type');
  const [taskType, setTaskType] = useState<TaskRow['task_type']>('single');
  const [category, setCategory] = useState<TaskRow['category']>('other');
  const [label, setLabel] = useState('');
  const [description, setDescription] = useState('');
  const [tag, setTag] = useState('');
  const [project, setProject] = useState('');
  const [startTime, setStartTime] = useState('');
  const [dueTime, setDueTime] = useState('');
  const [priority, setPriority] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const selectType = (t: typeof TASK_TYPES[number]) => {
    setTaskType(t.value as TaskRow['task_type']);
    setCategory(t.category);
    setStep('details');
  };

  const handleSave = async () => {
    if (!label.trim()) return;
    setSaving(true);
    setError(null);
    try {
      const created = await createTask({
        label: label.trim(),
        description: description.trim() || null,
        category,
        tag: tag.trim() || null,
        project_id: project.trim() || null,
        start_time: startTime.trim() || null,
        due_time: dueTime.trim() || null,
        priority: priority || null,
        task_type: taskType,
        done: false,
        sort_order: 999,
      });
      if (created) {
        onCreated(created);
      } else {
        setError('Could not create task.');
      }
    } catch {
      setError('Could not create task.');
    } finally {
      setSaving(false);
    }
  };

  const selectedType = TASK_TYPES.find((t) => t.value === taskType);

  return (
    <PageShell title="New Task" onBack={onBack}>
      {error && <p className="text-[12px] text-rose-300/70 mb-4">{error}</p>}

      {step === 'type' ? (
        <div className="flex flex-col gap-3">
          <p className="text-[13px] text-white/40 mb-2">Choose a task type</p>
          {TASK_TYPES.map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.value}
                onClick={() => selectType(t)}
                className="flex items-center gap-3 p-4 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 transition-all text-left"
              >
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-500/30 to-violet-500/30 flex items-center justify-center text-white/80 flex-shrink-0">
                  <Icon size={18} strokeWidth={1.8} />
                </div>
                <div className="flex-1">
                  <p className="text-[14px] text-white/90">{t.label}</p>
                  <p className="text-[11px] text-white/40">{t.desc}</p>
                </div>
              </button>
            );
          })}
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          {/* Type indicator */}
          <div className="flex items-center gap-2 mb-1">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-sky-500/30 to-violet-500/30 flex items-center justify-center text-white/70">
              {selectedType && <selectedType.icon size={14} strokeWidth={1.8} />}
            </div>
            <span className="text-[13px] text-white/60">{selectedType?.label}</span>
            <button
              onClick={() => setStep('type')}
              className="ml-auto text-[12px] text-white/40 hover:text-white/70 transition-colors"
            >
              Change
            </button>
          </div>

          <EditField label="Task name">
            <input
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              placeholder="What needs to be done?"
              className="edit-input"
              autoFocus
            />
          </EditField>

          <EditField label="Description">
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Optional details"
              className="edit-input min-h-[72px] resize-none"
            />
          </EditField>

          <EditField label="Tag / type label">
            <input
              value={tag}
              onChange={(e) => setTag(e.target.value)}
              placeholder="e.g. Design, Health"
              className="edit-input"
            />
          </EditField>

          {(taskType === 'project' || taskType === 'learning') && (
            <EditField label="Project">
              <input
                value={project}
                onChange={(e) => setProject(e.target.value)}
                placeholder="Project name"
                className="edit-input"
              />
            </EditField>
          )}

          <div className="grid grid-cols-2 gap-3">
            <EditField label="Start time">
              <input
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                placeholder="09:00"
                className="edit-input"
              />
            </EditField>
            <EditField label="Due time">
              <input
                value={dueTime}
                onChange={(e) => setDueTime(e.target.value)}
                placeholder="20 Oct, 20:00"
                className="edit-input"
              />
            </EditField>
          </div>

          <EditField label="Priority">
            <div className="flex gap-2">
              {PRIORITIES.map((p) => (
                <button
                  key={p.value}
                  onClick={() => setPriority(p.value)}
                  className={`flex-1 py-2 rounded-xl text-[12px] border transition-colors ${
                    priority === p.value
                      ? 'bg-white/15 border-white/30 text-white'
                      : 'bg-white/5 border-white/10 text-white/50 hover:bg-white/10'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </EditField>

          <div className="flex gap-3 mt-2">
            <button
              onClick={handleSave}
              disabled={!label.trim() || saving}
              className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-sky-500/80 to-violet-500/80 text-white/90 text-[13px] disabled:opacity-30 disabled:cursor-not-allowed hover:from-sky-500 hover:to-violet-500 transition-all"
            >
              {saving ? 'Saving...' : 'Create task'}
            </button>
            <button
              onClick={onBack}
              className="flex-1 py-2.5 rounded-xl border border-white/10 bg-white/5 text-white/60 text-[13px] hover:bg-white/10 transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </PageShell>
  );
}

function EditField({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1.5">
      <span className="text-[12px] tracking-wide text-white/40 uppercase">{label}</span>
      {children}
    </div>
  );
}
