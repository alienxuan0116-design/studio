import { projects } from '@/data';
import PageShell from '../components/PageShell';

interface Props {
  onBack: () => void;
}

export default function ProjectsPage({ onBack }: Props) {
  return (
    <PageShell title="Projects" subtitle="Progress overview" onBack={onBack}>
      <div className="flex flex-col gap-5">
        {projects.map((p) => (
          <div key={p.id}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-[14px] text-white/85">{p.name}</span>
              <span className="text-[13px] tabular-nums text-white/55">{p.progress}%</span>
            </div>
            <div className="h-2 rounded-full bg-white/8 overflow-hidden">
              <div
                className={`h-full rounded-full bg-gradient-to-r ${p.accent} shadow-[0_0_12px_rgba(120,150,255,0.4)]`}
                style={{ width: `${p.progress}%`, transition: 'width 0.8s cubic-bezier(0.22,1,0.36,1)' }}
              />
            </div>
          </div>
        ))}
      </div>
    </PageShell>
  );
}
