import { events } from '@/data';
import PageShell from '../components/PageShell';

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

function formatHour(h: number) {
  const hh = Math.floor(h);
  const m = Math.round((h - hh) * 60);
  const ampm = hh >= 12 ? 'PM' : 'AM';
  const h12 = hh % 12 || 12;
  return m === 0 ? `${h12} ${ampm}` : `${h12}:${m.toString().padStart(2, '0')} ${ampm}`;
}

interface Props {
  onBack: () => void;
}

export default function SchedulePage({ onBack }: Props) {
  const today = new Date();
  const monthName = today.toLocaleString('en-US', { month: 'long' });
  const year = today.getFullYear();
  const daysInMonth = new Date(year, today.getMonth() + 1, 0).getDate();
  const firstWeekday = new Date(year, today.getMonth(), 1).getDay();
  const todayDate = today.getDate();

  const cells: (number | null)[] = [];
  for (let i = 0; i < firstWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  return (
    <PageShell title="Schedule" subtitle={`${monthName} ${year}`} onBack={onBack}>
      {/* Month grid */}
      <div className="grid grid-cols-7 gap-1.5 mb-6">
        {DAYS.map((d) => (
          <span key={d} className="text-center text-[10px] tracking-wide text-white/35 uppercase">
            {d}
          </span>
        ))}
        {cells.map((d, i) => (
          <div
            key={i}
            className={`aspect-square rounded-lg flex items-center justify-center text-[13px] tabular-nums ${
              d === todayDate
                ? 'bg-gradient-to-br from-sky-500/40 to-violet-500/40 text-white border border-white/20'
                : d
                ? 'bg-white/5 text-white/60 hover:bg-white/10 transition-colors'
                : ''
            }`}
          >
            {d ?? ''}
          </div>
        ))}
      </div>

      {/* Today's events */}
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-sm tracking-[0.2em] uppercase text-white/50">Today</h2>
        <span className="text-[11px] text-white/35">{events.length} events</span>
      </div>
      <div className="flex flex-col gap-3">
        {events.map((ev) => (
          <div key={ev.id} className="flex items-center gap-3 p-3 rounded-xl bg-white/5">
            <div className={`w-2 h-10 rounded-full bg-gradient-to-b ${ev.color}`} />
            <div className="flex-1">
              <p className="text-[14px] text-white/85">{ev.title}</p>
              <p className="text-[11px] text-white/45 tabular-nums">
                {formatHour(ev.startHour)} – {formatHour(ev.endHour)}
              </p>
            </div>
          </div>
        ))}
      </div>
    </PageShell>
  );
}
