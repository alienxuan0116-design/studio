import { useEffect, useState, useCallback } from 'react';
import { Check, Plus, Trash2, Pencil, X } from 'lucide-react';
import PageShell from '@/components/PageShell';
import { fetchTask, fetchSubtasks, updateTask, toggleTaskDone, addSubtask, toggleSubtask, updateSubtask, deleteSubtask, type TaskRow, type SubtaskRow } from '@/lib/tasks';

interface Props {
  taskId: string;
  onBack: () => void;
}

const PRIORITIES = [
  { value: 'low', label: 'Low' },
  { value: 'medium', label: 'Medium' },
  { value: 'high', label: 'High' },
];

const TASK_TYPES: Record<string, string> = {
  essential: 'Daily Essential',
  single: 'Single Task',
  project: 'Project Task',
  learning: 'Learning Task',
};

export default function TaskDetailPage({ taskId, onBack }: Props) {
  const [task, setTask] = useState<TaskRow | null>(null);
  const [subtasks, setSubtasks] = useState<SubtaskRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [editing, setEditing] = useState(false);
  const [newSubtask, setNewSubtask] = useState('');
  const [editingSubtaskId, setEditingSubtaskId] = useState<string | null>(null);
  const [editSubtaskLabel, setEditSubtaskLabel] = useState('');

  const [editLabel, setEditLabel] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editTag, setEditTag] = useState('');
  const [editProject, setEditProject] = useState('');
  const [editStart, setEditStart] = useState('');
  const [editDue, setEditDue] = useState('');
  const [editPriority, setEditPriority] = useState('');
  const [editDone, setEditDone] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [t, subs] = await Promise.all([fetchTask(taskId), fetchSubtasks(taskId)]);
      setTask(t);
      setSubtasks(subs);
    } catch {
      setError('Could not load task.');
    } finally {
      setLoading(false);
    }
  }, [taskId]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const startEditing = () => {
    if (!task) return;
    setEditLabel(task.label);
    setEditDescription(task.description ?? '');
    setEditTag(task.tag ?? '');
    setEditProject(task.project_id ?? '');
    setEditStart(task.start_time ?? '');
    setEditDue(task.due_time ?? '');
    setEditPriority(task.priority ?? '');
    setEditDone(task.done);
    setEditing(true);
  };

  const saveEdits = async () => {
    if (!task) return;
    try {
      await updateTask(task.id, {
        label: editLabel.trim() || task.label,
        description: editDescription.trim() || null,
        tag: editTag.trim() || null,
        project_id: editProject.trim() || null,
        start_time: editStart.trim() || null,
        due_time: editDue.trim() || null,
        priority: editPriority || null,
        done: editDone,
      });
      setTask({
        ...task,
        label: editLabel.trim() || task.label,
        description: editDescription.trim() || null,
        tag: editTag.trim() || null,
        project_id: editProject.trim() || null,
        start_time: editStart.trim() || null,
        due_time: editDue.trim() || null,
        priority: editPriority || null,
        done: editDone,
      });
      setEditing(false);
    } catch {
      setError('Could not save changes.');
    }
  };

  const handleToggleDone = async () => {
    if (!task) return;
    const newDone = !task.done;
    setTask({ ...task, done: newDone });
    try {
      await toggleTaskDone(task.id, newDone);
    } catch {
      setTask({ ...task, done: !newDone });
      setError('Could not update status.');
    }
  };

  const handleAddSubtask = async () => {
    if (!task || !newSubtask.trim()) return;
    try {
      const sub = await addSubtask(task.id, newSubtask.trim());
      if (sub) {
        setSubtasks((prev) => [...prev, sub]);
        setNewSubtask('');
      }
    } catch {
      setError('Could not add subtask.');
    }
  };

  const handleToggleSubtask = async (id: string, currentDone: boolean) => {
    setSubtasks((prev) => prev.map((s) => (s.id === id ? { ...s, done: !currentDone } : s)));
    try {
      await toggleSubtask(id, !currentDone);
    } catch {
      setSubtasks((prev) => prev.map((s) => (s.id === id ? { ...s, done: currentDone } : s)));
    }
  };

  const handleEditSubtask = async (id: string) => {
    if (!editSubtaskLabel.trim()) return;
    try {
      await updateSubtask(id, editSubtaskLabel.trim());
      setSubtasks((prev) => prev.map((s) => (s.id === id ? { ...s, label: editSubtaskLabel.trim() } : s)));
      setEditingSubtaskId(null);
      setEditSubtaskLabel('');
    } catch {
      setError('Could not update subtask.');
    }
  };

  const handleDeleteSubtask = async (id: string) => {
    setSubtasks((prev) => prev.filter((s) => s.id !== id));
    try {
      await deleteSubtask(id);
    } catch {
      setError('Could not delete subtask.');
    }
  };

  if (loading) {
    return (
      <PageShell title="Task" onBack={onBack}>
        <p className="text-[13px] text-white/35">Loading...</p>
      </PageShell>
    );
  }

  if (error && !task) {
    return (
      <PageShell title="Task" onBack={onBack}>
        <p className="text-[13px] text-white/50">{error}</p>
      </PageShell>
    );
  }

  if (!task) {
    return (
      <PageShell title="Task" onBack={onBack}>
        <p className="text-[13px] text-white/50">Task not found.</p>
      </PageShell>
    );
  }

  const completedCount = subtasks.filter((s) => s.done).length;

  return (
    <PageShell title="Task Details" onBack={onBack}>
      {error && (
        <p className="text-[12px] text-rose-300/70 mb-4">{error}</p>
      )}

      {/* View mode */}
      {!editing ? (
        <div className="flex flex-col gap-5">
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1">
              <h2 className={`text-lg font-light ${task.done ? 'text-white/40 line-through' : 'text-white/90'}`}>
                {task.label}
              </h2>
              {task.tag && (
                <span className="text-[11px] tracking-wide text-white/40 uppercase mt-1 inline-block">{task.tag}</span>
              )}
            </div>
            <button
              onClick={startEditing}
              className="rail-icon w-8 h-8 rounded-lg flex items-center justify-center text-white/50 hover:text-white/80 border border-white/10 bg-white/5 flex-shrink-0"
              aria-label="Edit task"
            >
              <Pencil size={14} strokeWidth={1.8} />
            </button>
          </div>

          <button
            onClick={handleToggleDone}
            className="flex items-center gap-3 py-2.5 px-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors text-left"
          >
            <span className={`check ${task.done ? 'checked' : ''}`}>
              <Check size={14} strokeWidth={3} color="#fff" />
            </span>
            <span className="text-[14px] text-white/70">{task.done ? 'Completed' : 'Mark as done'}</span>
          </button>

          <div className="flex flex-col gap-3">
            <FieldRow label="Description" value={task.description} />
            <FieldRow label="Type" value={TASK_TYPES[task.task_type] ?? task.task_type} />
            <FieldRow label="Project" value={task.project_id} />
            <FieldRow label="Start time" value={task.start_time} />
            <FieldRow label="Due time" value={task.due_time} />
            <FieldRow label="Priority" value={task.priority ? PRIORITIES.find((p) => p.value === task.priority)?.label : null} />
            <FieldRow label="Status" value={task.done ? 'Completed' : 'In progress'} />
          </div>

          {/* Subtasks */}
          <div className="mt-2">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm tracking-[0.2em] uppercase text-white/50">Subtasks</h3>
              <span className="text-[11px] tabular-nums text-white/40">{completedCount}/{subtasks.length}</span>
            </div>

            {subtasks.length > 0 && (
              <div className="flex flex-col gap-1.5 mb-3">
                {subtasks.map((sub) => (
                  <div key={sub.id} className="flex items-center gap-2 py-2 px-2 rounded-xl hover:bg-white/5 transition-colors group">
                    <button
                      onClick={() => handleToggleSubtask(sub.id, sub.done)}
                      className={`check ${sub.done ? 'checked' : ''} flex-shrink-0`}
                    >
                      <Check size={12} strokeWidth={3} color="#fff" />
                    </button>
                    {editingSubtaskId === sub.id ? (
                      <div className="flex-1 flex items-center gap-2">
                        <input
                          value={editSubtaskLabel}
                          onChange={(e) => setEditSubtaskLabel(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && handleEditSubtask(sub.id)}
                          className="flex-1 bg-white/5 border border-white/15 rounded-lg px-2 py-1 text-[13px] text-white/90 focus:outline-none focus:border-white/30"
                          autoFocus
                        />
                        <button onClick={() => handleEditSubtask(sub.id)} className="text-white/50 hover:text-white/80">
                          <Check size={14} />
                        </button>
                        <button onClick={() => setEditingSubtaskId(null)} className="text-white/50 hover:text-white/80">
                          <X size={14} />
                        </button>
                      </div>
                    ) : (
                      <>
                        <span className={`flex-1 text-[14px] ${sub.done ? 'text-white/40 line-through' : 'text-white/80'}`}>
                          {sub.label}
                        </span>
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => { setEditingSubtaskId(sub.id); setEditSubtaskLabel(sub.label); }}
                            className="text-white/40 hover:text-white/70"
                            aria-label="Edit subtask"
                          >
                            <Pencil size={13} strokeWidth={1.6} />
                          </button>
                          <button
                            onClick={() => handleDeleteSubtask(sub.id)}
                            className="text-white/40 hover:text-rose-300/70"
                            aria-label="Delete subtask"
                          >
                            <Trash2 size={13} strokeWidth={1.6} />
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                ))}
              </div>
            )}

            <div className="flex items-center gap-2">
              <input
                value={newSubtask}
                onChange={(e) => setNewSubtask(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddSubtask()}
                placeholder="Add a subtask..."
                className="flex-1 bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-[13px] text-white/90 placeholder:text-white/30 focus:outline-none focus:border-white/25 transition-colors"
              />
              <button
                onClick={handleAddSubtask}
                disabled={!newSubtask.trim()}
                className="rail-icon w-9 h-9 rounded-xl flex items-center justify-center text-white/50 border border-white/10 bg-white/5 disabled:opacity-30 flex-shrink-0"
                aria-label="Add subtask"
              >
                <Plus size={16} strokeWidth={2} />
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Edit mode */
        <div className="flex flex-col gap-4">
          <EditField label="Task name">
            <input
              value={editLabel}
              onChange={(e) => setEditLabel(e.target.value)}
              className="edit-input"
            />
          </EditField>

          <EditField label="Description">
            <textarea
              value={editDescription}
              onChange={(e) => setEditDescription(e.target.value)}
              className="edit-input min-h-[80px] resize-none"
            />
          </EditField>

          <EditField label="Tag / type label">
            <input
              value={editTag}
              onChange={(e) => setEditTag(e.target.value)}
              placeholder="e.g. Design, Health"
              className="edit-input"
            />
          </EditField>

          <EditField label="Project">
            <input
              value={editProject}
              onChange={(e) => setEditProject(e.target.value)}
              placeholder="Project name"
              className="edit-input"
            />
          </EditField>

          <div className="grid grid-cols-2 gap-3">
            <EditField label="Start time">
              <input
                value={editStart}
                onChange={(e) => setEditStart(e.target.value)}
                placeholder="09:00"
                className="edit-input"
              />
            </EditField>
            <EditField label="Due time">
              <input
                value={editDue}
                onChange={(e) => setEditDue(e.target.value)}
                placeholder="20 Oct, 20:00"
                className="edit-input"
              />
            </EditField>
          </div>

          <EditField label="Priority">
            <div className="flex gap-2">
              {PRIORITIES.map((p) => (
                <button
                  key={p.value}
                  onClick={() => setEditPriority(p.value)}
                  className={`flex-1 py-2 rounded-xl text-[12px] border transition-colors ${
                    editPriority === p.value
                      ? 'bg-white/15 border-white/30 text-white'
                      : 'bg-white/5 border-white/10 text-white/50 hover:bg-white/10'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </EditField>

          <EditField label="Status">
            <button
              onClick={() => setEditDone(!editDone)}
              className="flex items-center gap-3 py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors w-full"
            >
              <span className={`check ${editDone ? 'checked' : ''}`}>
                <Check size={14} strokeWidth={3} color="#fff" />
              </span>
              <span className="text-[14px] text-white/70">{editDone ? 'Completed' : 'In progress'}</span>
            </button>
          </EditField>

          <div className="flex gap-3 mt-2">
            <button
              onClick={saveEdits}
              className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-sky-500/80 to-violet-500/80 text-white/90 text-[13px] hover:from-sky-500 hover:to-violet-500 transition-all"
            >
              Save
            </button>
            <button
              onClick={() => setEditing(false)}
              className="flex-1 py-2.5 rounded-xl border border-white/10 bg-white/5 text-white/60 text-[13px] hover:bg-white/10 transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </PageShell>
  );
}

function FieldRow({ label, value }: { label: string; value: string | null | undefined }) {
  return (
    <div className="flex items-start justify-between gap-3 py-1">
      <span className="text-[12px] tracking-wide text-white/40 uppercase flex-shrink-0">{label}</span>
      <span className={`text-[13px] text-right ${value ? 'text-white/80' : 'text-white/25'}`}>
        {value || '—'}
      </span>
    </div>
  );
}

function EditField({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1.5">
      <span className="text-[12px] tracking-wide text-white/40 uppercase">{label}</span>
      {children}
    </div>
  );
}
