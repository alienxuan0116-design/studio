/*
# Create tasks and subtasks tables (single-tenant, no auth)

1. New Tables
- `tasks`: Stores all tasks across categories (essentials, focus, other, project, learning).
  - `id` (uuid, primary key)
  - `label` (text, not null) — task name
  - `description` (text, nullable) — longer description
  - `done` (boolean, default false) — completion status
  - `category` (text, not null) — which list this task belongs to: 'essential' | 'focus' | 'other'
  - `tag` (text, nullable) — short type label e.g. 'Health', 'Design'
  - `project_id` (text, nullable) — name of associated project if any
  - `start_time` (text, nullable) — start time string e.g. '09:00'
  - `due_time` (text, nullable) — due time string e.g. '20 Oct, 20:00'
  - `priority` (text, nullable) — 'low' | 'medium' | 'high'
  - `task_type` (text, not null, default 'single') — 'essential' | 'single' | 'project' | 'learning'
  - `sort_order` (integer, default 0) — ordering within a category
  - `created_at` (timestamptz, default now())

- `subtasks`: Stores subtasks belonging to a parent task.
  - `id` (uuid, primary key)
  - `task_id` (uuid, foreign key to tasks.id ON DELETE CASCADE)
  - `label` (text, not null)
  - `done` (boolean, default false)
  - `sort_order` (integer, default 0)
  - `created_at` (timestamptz, default now())

2. Security
- Enable RLS on both tables.
- Allow anon + authenticated full CRUD because this is a single-tenant app with no sign-in.
- USING (true) / WITH CHECK (true) is acceptable here because all data is intentionally shared.

3. Important Notes
- This is a no-auth single-tenant app; the anon-key frontend needs full read/write access.
- Subtasks cascade-delete with their parent task.
- Existing in-memory data from data.ts will be seeded into these tables on first app load.
*/

CREATE TABLE IF NOT EXISTS tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  label text NOT NULL,
  description text,
  done boolean NOT NULL DEFAULT false,
  category text NOT NULL DEFAULT 'other',
  tag text,
  project_id text,
  start_time text,
  due_time text,
  priority text,
  task_type text NOT NULL DEFAULT 'single',
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS subtasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  label text NOT NULL,
  done boolean NOT NULL DEFAULT false,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE subtasks ENABLE ROW LEVEL SECURITY;

-- Tasks policies
DROP POLICY IF EXISTS "anon_select_tasks" ON tasks;
CREATE POLICY "anon_select_tasks" ON tasks FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_tasks" ON tasks;
CREATE POLICY "anon_insert_tasks" ON tasks FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_tasks" ON tasks;
CREATE POLICY "anon_update_tasks" ON tasks FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_tasks" ON tasks;
CREATE POLICY "anon_delete_tasks" ON tasks FOR DELETE
  TO anon, authenticated USING (true);

-- Subtasks policies
DROP POLICY IF EXISTS "anon_select_subtasks" ON subtasks;
CREATE POLICY "anon_select_subtasks" ON subtasks FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_subtasks" ON subtasks;
CREATE POLICY "anon_insert_subtasks" ON subtasks FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_subtasks" ON subtasks;
CREATE POLICY "anon_update_subtasks" ON subtasks FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_subtasks" ON subtasks;
CREATE POLICY "anon_delete_subtasks" ON subtasks FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_tasks_category ON tasks(category);
CREATE INDEX IF NOT EXISTS idx_subtasks_task_id ON subtasks(task_id);
