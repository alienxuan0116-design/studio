/*
# Change task and subtask ID columns from uuid to text

The existing in-memory task data uses string IDs like 'e1', 'f1', 'o1'.
To preserve these IDs when seeding the database, the id columns must be text, not uuid.
This migration recreates both tables with text PKs and text FK references.

1. Changes
- `tasks.id`: text PRIMARY KEY (was uuid)
- `subtasks.id`: text PRIMARY KEY (was uuid)
- `subtasks.task_id`: text REFERENCES tasks(id) (was uuid)

2. Security
- RLS policies unchanged (re-created with same names).
*/
DROP TABLE IF EXISTS subtasks;
DROP TABLE IF EXISTS tasks;

CREATE TABLE IF NOT EXISTS tasks (
  id text PRIMARY KEY,
  label text NOT NULL,
  description text,
  done boolean NOT NULL DEFAULT false,
  category text NOT NULL DEFAULT 'other',
  tag text,
  project_id text,
  start_time text,
  due_time text,
  priority text,
  task_type text NOT NULL DEFAULT 'single',
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS subtasks (
  id text PRIMARY KEY DEFAULT gen_random_uuid()::text,
  task_id text NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  label text NOT NULL,
  done boolean NOT NULL DEFAULT false,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE subtasks ENABLE ROW LEVEL SECURITY;

-- Tasks policies
DROP POLICY IF EXISTS "anon_select_tasks" ON tasks;
CREATE POLICY "anon_select_tasks" ON tasks FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_tasks" ON tasks;
CREATE POLICY "anon_insert_tasks" ON tasks FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_tasks" ON tasks;
CREATE POLICY "anon_update_tasks" ON tasks FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_tasks" ON tasks;
CREATE POLICY "anon_delete_tasks" ON tasks FOR DELETE
  TO anon, authenticated USING (true);

-- Subtasks policies
DROP POLICY IF EXISTS "anon_select_subtasks" ON subtasks;
CREATE POLICY "anon_select_subtasks" ON subtasks FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_subtasks" ON subtasks;
CREATE POLICY "anon_insert_subtasks" ON subtasks FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_subtasks" ON subtasks;
CREATE POLICY "anon_update_subtasks" ON subtasks FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_subtasks" ON subtasks;
CREATE POLICY "anon_delete_subtasks" ON subtasks FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_tasks_category ON tasks(category);
CREATE INDEX IF NOT EXISTS idx_subtasks_task_id ON subtasks(task_id);
